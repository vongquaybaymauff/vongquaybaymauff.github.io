<?php 

    echo "Chào Bạn";

/* Nông Văn Nguyên */
?>